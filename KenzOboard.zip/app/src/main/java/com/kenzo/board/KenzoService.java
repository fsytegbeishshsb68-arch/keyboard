package com.kenzo.board;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.inputmethodservice.InputMethodService;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class KenzoService extends InputMethodService {
    static final String[] AR = {"ضصثقفغعهخحجد", "شسيبلاتنمكط", "ئءؤرىةوزظذ"};
    static final String[] EN = {"qwertyuiop", "asdfghjkl", "zxcvbnm"};
    static final String[] UNITS = {"", "ألف", "مليون", "مليار", "تريليون", "كوادريليون",
            "كوينتليون", "سكستليون", "سبتليون", "أوكتليون", "نونليون", "ديسليون"};
    static final int OFF = 0xFF1E1E1E, ON = 0xFF1B5E20;

    boolean arabic = true, shift = false, autoSend = false, spread = false;
    int target = 10, count = 0;
    final Handler h = new Handler(Looper.getMainLooper());
    FrameLayout root;
    LinearLayout kb, letters;
    ScrollView panel;
    TextView tAuto, tSpread, tTarget, tLang;
    float dens = 1f;

    int dp(int v) { return Math.round(v * dens); }

    GradientDrawable bg(int c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(c);
        g.setCornerRadius(dp(8));
        return g;
    }

    void setBase(TextView t, int c) { t.setTag(c); t.setBackground(bg(c)); }

    TextView key(String label, float w, final boolean rep, final Runnable r) {
        final TextView t = new TextView(this);
        t.setText(label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(18);
        t.setGravity(Gravity.CENTER);
        setBase(t, OFF);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w);
        p.setMargins(dp(2), dp(3), dp(2), dp(3));
        t.setLayoutParams(p);
        t.setOnTouchListener(new View.OnTouchListener() {
            Runnable loop;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        t.setBackground(bg(0xFF555555));
                        r.run();
                        if (rep) {
                            loop = new Runnable() {
                                @Override public void run() { r.run(); h.postDelayed(this, 45); }
                            };
                            h.postDelayed(loop, 350);
                        }
                        break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        t.setBackground(bg((Integer) t.getTag()));
                        if (loop != null) h.removeCallbacks(loop);
                        break;
                    default:
                        break;
                }
                return true;
            }
        });
        return t;
    }

    LinearLayout row(int hdp) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(hdp)));
        return r;
    }

    @Override public boolean onEvaluateFullscreenMode() { return false; }

    @Override public void onStartInputView(EditorInfo info, boolean restarting) {
        super.onStartInputView(info, restarting);
        count = 0;
        if (panel != null) showPanel(false);
    }

    @Override public View onCreateInputView() {
        dens = getResources().getDisplayMetrics().density;
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        kb = new LinearLayout(this);
        kb.setOrientation(LinearLayout.VERTICAL);
        kb.setPadding(dp(3), dp(3), dp(3), dp(3));

        LinearLayout nr = row(46);
        for (char c = '0'; c <= '9'; c++) {
            final String s = String.valueOf(c);
            nr.addView(key(s, 1f, false, () -> typeDigit(s)));
        }
        kb.addView(nr);

        letters = new LinearLayout(this);
        letters.setOrientation(LinearLayout.VERTICAL);
        kb.addView(letters, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout br = row(46);
        br.addView(key("⚙", 1f, false, () -> showPanel(true)));
        tLang = key("EN", 1f, false, () -> { arabic = !arabic; h.post(this::rebuild); });
        br.addView(tLang);
        br.addView(key("⇧", 1f, false, () -> { shift = !shift; h.post(this::rebuild); }));
        br.addView(key(",", 1f, false, () -> typeChar(",")));
        br.addView(key("KenzO", 3f, false, () -> { commit(" "); count = 0; }));
        br.addView(key(".", 1f, false, () -> typeChar(".")));
        br.addView(key("⌫", 1.3f, true, this::backspace));
        br.addView(key("↵", 1.3f, false, this::sendNow));
        kb.addView(br);

        root.addView(kb, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        buildPanel();
        root.addView(panel, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        panel.setVisibility(View.GONE);
        rebuild();
        return root;
    }

    void rebuild() {
        letters.removeAllViews();
        String[] src = arabic ? AR : EN;
        for (String r : src) {
            LinearLayout row = row(46);
            for (int i = 0; i < r.length(); i++) {
                String ch = String.valueOf(r.charAt(i));
                final String out = (!arabic && shift) ? ch.toUpperCase() : ch;
                row.addView(key(out, 1f, false, () -> typeChar(out)));
            }
            letters.addView(row);
        }
        if (tLang != null) tLang.setText(arabic ? "EN" : "ع");
    }

    void buildPanel() {
        panel = new ScrollView(this);
        panel.setBackgroundColor(0xFF0A0A0A);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(6), dp(6), dp(6), dp(6));
        panel.addView(col);

        LinearLayout hd = row(44);
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.kenzo);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hd.addView(iv, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView title = new TextView(this);
        title.setText("KenzO board");
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setGravity(Gravity.CENTER);
        hd.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        hd.addView(key("✕", 0.5f, false, () -> showPanel(false)));
        col.addView(hd);

        LinearLayout r2 = row(48);
        TextView tk = key("فكّك آخر كلمة", 1f, false, this::tafkik);
        tk.setTextSize(15);
        r2.addView(tk);
        tSpread = key("", 1f, false, () -> { spread = !spread; refresh(); });
        tSpread.setTextSize(15);
        r2.addView(tSpread);
        col.addView(r2);

        LinearLayout r3 = row(48);
        tAuto = key("", 1f, false, () -> { autoSend = !autoSend; count = 0; refresh(); });
        tAuto.setTextSize(15);
        r3.addView(tAuto);
        col.addView(r3);

        LinearLayout r4 = row(48);
        r4.addView(key("-10", 1f, true, () -> adj(-10)));
        r4.addView(key("-", 1f, true, () -> adj(-1)));
        tTarget = key("", 2f, false, () -> { });
        r4.addView(tTarget);
        r4.addView(key("+", 1f, true, () -> adj(1)));
        r4.addView(key("+10", 1f, true, () -> adj(10)));
        col.addView(r4);

        TextView lb = new TextView(this);
        lb.setText("اختر عدد الخانات (يفعّل الإرسال التلقائي):");
        lb.setTextColor(Color.WHITE);
        lb.setTextSize(14);
        lb.setGravity(Gravity.CENTER);
        lb.setPadding(0, dp(6), 0, dp(6));
        col.addView(lb);

        for (int n = 1; n <= 101; n += 3) {
            LinearLayout gr = row(54);
            for (int k = n; k < n + 3 && k <= 101; k++) {
                final int num = k;
                TextView b = key(k + " خانة\n" + name(k), 1f, false, () -> select(num));
                b.setTextSize(13);
                gr.addView(b);
            }
            col.addView(gr);
        }
        refresh();
    }

    String name(int n) {
        if (n == 101) return "جوجل";
        int g = (n - 1) / 3, p = (n - 1) % 3;
        if (g == 0) return p == 0 ? "آحاد" : (p == 1 ? "عشرات" : "مئات");
        if (g >= UNITS.length) return "";
        return p == 0 ? UNITS[g] : ((p == 1 ? "عشرات " : "مئات ") + UNITS[g]);
    }

    void refresh() {
        tSpread.setText("التفكيك التلقائي: " + (spread ? "مفعّل" : "مطفأ"));
        setBase(tSpread, spread ? ON : OFF);
        tAuto.setText("الإرسال التلقائي: " + (autoSend ? "مفعّل" : "مطفأ"));
        setBase(tAuto, autoSend ? ON : OFF);
        tTarget.setText(target + " خانة");
    }

    void adj(int d) {
        target = Math.max(1, Math.min(101, target + d));
        count = 0;
        refresh();
    }

    void select(int n) {
        target = n;
        autoSend = true;
        count = 0;
        refresh();
    }

    void showPanel(boolean show) {
        panel.setVisibility(show ? View.VISIBLE : View.GONE);
        kb.setVisibility(show ? View.INVISIBLE : View.VISIBLE);
        if (show) panel.scrollTo(0, 0);
    }

    void commit(String s) {
        InputConnection ic = getCurrentInputConnection();
        if (ic != null) ic.commitText(s, 1);
    }

    void typeChar(String s) {
        commit(spread ? s + " " : s);
        count = 0;
        if (shift) { shift = false; h.post(this::rebuild); }
    }

    void typeDigit(String s) {
        commit(s);
        count++;
        if (autoSend && count >= target) {
            count = 0;
            sendNow();
        }
    }

    void backspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_DEL));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_DEL));
        if (count > 0) count--;
    }

    void sendNow() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        EditorInfo ei = getCurrentInputEditorInfo();
        int a = ei == null ? 0 : (ei.imeOptions & EditorInfo.IME_MASK_ACTION);
        boolean noEnter = ei != null && (ei.imeOptions & EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0;
        if (a != EditorInfo.IME_ACTION_NONE && a != EditorInfo.IME_ACTION_UNSPECIFIED && !noEnter) {
            ic.performEditorAction(a);
        } else {
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
            ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
        }
        count = 0;
    }

    void tafkik() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        CharSequence cs = ic.getTextBeforeCursor(80, 0);
        if (cs == null || cs.length() == 0) return;
        String s = cs.toString();
        int end = s.length();
        while (end > 0 && Character.isWhitespace(s.charAt(end - 1))) end--;
        int st = end;
        while (st > 0 && !Character.isWhitespace(s.charAt(st - 1))) st--;
        if (st == end) return;
        String word = s.substring(st, end);
        String tail = s.substring(end);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < word.length(); i++) {
            if (i > 0) sb.append(' ');
            sb.append(word.charAt(i));
        }
        ic.deleteSurroundingText(s.length() - st, 0);
        ic.commitText(sb.toString() + tail, 1);
        count = 0;
    }
}
