package com.kenzo.board;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setGravity(Gravity.CENTER);
        l.setBackgroundColor(Color.BLACK);
        l.setPadding(40, 40, 40, 40);
        ImageView iv = new ImageView(this);
        iv.setImageResource(R.drawable.kenzo);
        l.addView(iv, new LinearLayout.LayoutParams(480, 480));
        TextView t = new TextView(this);
        t.setText("KenzO board");
        t.setTextColor(Color.WHITE);
        t.setTextSize(24);
        t.setGravity(Gravity.CENTER);
        l.addView(t);
        Button b1 = new Button(this);
        b1.setText("1) تفعيل الكيبورد");
        b1.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)));
        l.addView(b1);
        Button b2 = new Button(this);
        b2.setText("2) اختيار الكيبورد");
        b2.setOnClickListener(v -> ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker());
        l.addView(b2);
        setContentView(l);
    }
}
